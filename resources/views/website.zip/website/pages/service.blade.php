@extends('website.layout.main')

@section('content')
    
    <header class="bg-primary py-5 mb-5">
        <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-lg-12">
            <h1 class="display-4 text-white mt-5 mb-2">Services</h1>
            <p class="lead mb-5 text-white-50">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non possimus ab labore provident mollitia. Id assumenda voluptate earum corporis facere quibusdam quisquam iste ipsa cumque unde nisi, totam quas ipsam.</p>
            </div>
        </div>
        </div>
    </header>

    <div class="container">
        <div class="row">
        <div class="col-md-4 mb-5">
            <div class="card h-100">
            <img class="card-img-top" src="https://placehold.it/300x200" alt="">
            <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque sequi doloribus.</p>
            </div>
            <div class="card-footer">
                <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
            </div>
        </div>
        <div class="col-md-4 mb-5">
            <div class="card h-100">
            <img class="card-img-top" src="https://placehold.it/300x200" alt="">
            <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque sequi doloribus totam ut praesentium aut.</p>
            </div>
            <div class="card-footer">
                <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
            </div>
        </div>
        <div class="col-md-4 mb-5">
            <div class="card h-100">
            <img class="card-img-top" src="https://placehold.it/300x200" alt="">
            <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente esse necessitatibus neque.</p>
            </div>
            <div class="card-footer">
                <a href="#" class="btn btn-primary">Find Out More!</a>
            </div>
            </div>
        </div>
    </div>

    @stop
