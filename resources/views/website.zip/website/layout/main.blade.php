<!DOCTYPE html>
<html lang="en">
    @include('website.includes.head')
<body>

    @include('website.includes.nav')

    @yield('content')
    
    @include('website.includes.footer')

</body>
</html>
