<script src="website/vendor/jquery/jquery.min.js"></script>
<script src="website/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<footer class="py-5 bg-dark">
  <div class="container">
    <p class="m-0 text-center text-white">...............</p>
  </div>
</footer>